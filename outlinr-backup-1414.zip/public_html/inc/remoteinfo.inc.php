<?php
define('REMOTE_DB_NAME', 'jcole_ideaoverflow2_ma');
define('REMOTE_USER', 'USERNAME_HERE');
define('REMOTE_PASS', 'PASSWORD_HERE');