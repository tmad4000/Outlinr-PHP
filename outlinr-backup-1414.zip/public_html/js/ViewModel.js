//#TODO implement as base class
function ViewModel() {
	this.viewDomE=null; //until render is called for first time

}